import { Model, Sequelize } from "../Config/database.js";

const ClientActivityLog = Model.define('clientloginactivity_logs', {
    id: {
        type: Sequelize.BIGINT(20),
        autoIncrement: true,
        primaryKey: true
    },
    country: {
        type: Sequelize.STRING,
        allowNull: true
    },
    state: {
        type: Sequelize.STRING,
        allowNull: true
    },
    city: {
        type: Sequelize.STRING,
        allowNull: true
    },
    ip: {
        type: Sequelize.STRING,
        allowNull: true
    },
    latitude: {
        type: Sequelize.FLOAT,
        allowNull: true
    },
    longitude: {
        type: Sequelize.FLOAT,
        allowNull: true
    },
    zipcode: {
        type: Sequelize.INTEGER,
        allowNull: true
    },
    mobile: {
        type: Sequelize.CHAR(15),
        allowNull: true
    },
    email: {
        type: Sequelize.STRING,
        allowNull: true
    },
    appname: {
        type: Sequelize.STRING,
        allowNull: true
    }

});
await ClientActivityLog.sync();
 

export default ClientActivityLog;