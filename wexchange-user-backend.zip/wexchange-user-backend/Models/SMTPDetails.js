import { Model, Sequelize } from "../Config/database.js";

const SMTPDetails = Model.define('smtp_details', {
    id: {
        type: Sequelize.BIGINT(20),
        autoIncrement: true,
        primaryKey: true
    },
    email: {
        type: Sequelize.STRING,
        allowNull: false
    },
    password: {
        type: Sequelize.STRING,
        allowNull: false
    },
    status:{
        type: Sequelize.BOOLEAN,
        allowNull: false
    },
    mail_mailer:{
        type: Sequelize.STRING,
        allowNull: false
    },
    mail_host:{
        type: Sequelize.STRING,
        allowNull: false
    },
    mail_port:{
        type: Sequelize.INTEGER,
        allowNull: false
    },
    mail_from_address:{
        type: Sequelize.STRING,
        allowNull: false
    },
    mail_from_name:{
        type: Sequelize.STRING,
        allowNull: false
    },
    mail_encryption:{
        type: Sequelize.STRING,
        allowNull: false
    }
});
await SMTPDetails.sync();
 

export default SMTPDetails;