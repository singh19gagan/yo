import { Model, Sequelize } from "../Config/database.js";

const MailTemplate = Model.define('mail_templates', {
    id: {
        type: Sequelize.BIGINT(20),
        autoIncrement: true,
        primaryKey: true
    },
    title: {
        type: Sequelize.STRING,
        allowNull: true
    },
    template: {
        type: Sequelize.TEXT('long'),
        allowNull: true
    },

});
await MailTemplate.sync();
 
export default MailTemplate;