import { Model, Sequelize } from "../Config/database.js";

const RegistrationPending = Model.define('registration_pendings', {
    id: {
        type: Sequelize.BIGINT(20),
        autoIncrement: true,
        primaryKey: true
    },
    referal_id: {
        type: Sequelize.CHAR(10),
        unique: true,
        allowNull: false
    },
    referal_by: {
        type: Sequelize.CHAR(10),
        allowNull: true
    },
    region: {
        type: Sequelize.CHAR(10),
        allowNull: false
    },
    mobile: {
        type: Sequelize.INTEGER(15),
        allowNull: true
    },
    email: {
        type: Sequelize.STRING,
        allowNull: true
    },
    password: {
        type: Sequelize.STRING,
        allowNull: false
    }
});
await RegistrationPending.sync();
 

export default RegistrationPending;