import { Model, Sequelize } from "../Config/database.js";

const OtpSchema = Model.define('otp_schemas', {
    id: {
        type: Sequelize.BIGINT(20),
        autoIncrement: true,
        primaryKey: true
    },
     email: {
        type: Sequelize.STRING,
        allowNull: true
      },
      mobile: {
        type: Sequelize.INTEGER,
        allowNull: true
      },
      otp: {
        type: Sequelize.INTEGER(10),
        allowNull: false
     
      }
});
await OtpSchema.sync();
 

export default OtpSchema;

