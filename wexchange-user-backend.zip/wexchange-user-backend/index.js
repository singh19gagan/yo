import express from "express";
import { ApiRoute } from "./Routes/api.js"; 
import cors from './Config/cors.js'; 

const PORT = process.env.PORT || 3000;
const app = express();
app.use(express.json()); 
app.use(cors) 



app.use('/api', ApiRoute);

app.listen(PORT, () => {
    console.log(`Server running on ${PORT}`);
});