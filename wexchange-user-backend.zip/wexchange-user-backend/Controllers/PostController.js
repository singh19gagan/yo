import SMTPDetails from "../Models/SMTPDetails.js";
import MailTemplate from "../Models/MailTemplate.js";
import ClientActivityLog from "../Models/ClientActivityLog.js";

import reply from "../Utils/reply.js";
const registerSMTPUser = async (req, res) => {
    let request = req.body;
  
 
    // const saltRounds = 10;
    // const salt = bcrypt.genSaltSync(saltRounds);
    // let password = bcrypt.hashSync(request.password, salt);
    // request.password = password; 

    
   
    console.log("request",request);

    try {
          const newUser = await SMTPDetails.create(request);
          console.log('SMTPUser registered successfully:', newUser.toJSON());

         
   
    return res.json(reply.success("SMTP User Registration successfully"));

   
    } catch (err) {
  
      console.log({err});
      return res.json(reply.failed("error", err));
        }
  
  
  }

  const setTemplate = async (req, res) => {
    let request = req.body;
   
    console.log("request",request);

    try {
          const newTemplate = await MailTemplate.create(request);
          console.log('Template created successfully:', newTemplate.toJSON());

         
   
    return res.json(reply.success("Template created successfully"));

   
    } catch (err) {
  
      console.log({err});
      return res.json(reply.failed("error", err));
        }
  
  
  }

  const setUserDetails = async (req, res) => {
    let request = req.body;
   
    console.log("request",request);

    try {
          const Log = await ClientActivityLog.create(request);
          console.log("log",Log)
          console.log('ClientActivityLog created successfully:', Log.toJSON());

          return res.json(reply.success("ClientActivityLog created successfully"));

   
    } catch (err) {
  
      console.log({err});
      return res.json(reply.failed("error", err));
        }
  
  
  }
  
  export default {
    registerSMTPUser,
    setTemplate,
    setUserDetails
  }