
import RegPending from "../Models/RegistrationPending.js";
import Users from "../Models/Users.js";
import bcrypt from 'bcryptjs'
import reply from "../Utils/reply.js"
import helper from "../Utils/helpers.js"
import OtpSchema from "../Models/OtpSchema.js";
import Validator from "validatorjs";
import Mail from "../Common/Mail.js";
import JWT from 'jsonwebtoken';
import LoginActivityLog from "../Models/LoginActivityLog.js";
import ClientActivityLog from "../Models/ClientActivityLog.js";
import axios from 'axios'
import { Address6 } from 'ip-address';
import randomstring from 'randomstring';

const fetchAndSaveData = async (email, ipAddress) => {
  try {
    const response = await axios.get(`https://api.ipgeolocation.io/ipgeo?apiKey=ae15bac6dd604097a05c068ae64fa361&ip=${ipAddress}`);

    const details = await LoginActivityLog.create({
      email: email,
      ip: response.data.ip,
      state: response.data.state_prov,
      country: response.data.country_name,
      city: response.data.city,
      latitude: response.data.latitude,
      longitude: response.data.longitude,
      zipcode: response.data.zipcode
    });
    

    console.log("details saved in loginactivtylog", details.toJSON())

  } catch (error) {
    console.error('Error:', error);
  }
};

const generateReferalId = async () => {
  let result = randomstring.generate(6);
  let referal_id = `GDCC${result}`;

  console.log("refid", referal_id)

  let existId = await getUserByRefId(referal_id);
  if (!existId) return referal_id;
  return generateReferalId();

}

const getUserByRefId = async (referal_id) => {
  let user = await RegPending.findOne({ where: { referal_id } }) || await Users.findOne({ where: { referal_id } });

  return user;
}

const isGmail = (email) => {
  return email.endsWith('@gmail.com');
};

function checkPasswordStrength(password) {
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,}$/;
  return passwordRegex.test(password);
}



function IsemailOrMobile(value) {
  const emailRegex = /^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)*(\.[a-zA-Z]{2,})$/;
  const numberRegex = /^\d{10}$/;

  if (emailRegex.test(value)) {
    if (!isGmail(value))
      return 'not gmail'

    return 'email';
  } else if (numberRegex.test(value)) {
    return 'number';
  } else {
    return 'invalid';
  }
}

const register = async (req, res) => {
  let request = req.body;

  if (!request.email || !request.password) {
    return res.json(reply.failed("Credentials required"));
  }

  const value = IsemailOrMobile(request.email);
  console.log("value", value)
  if (value === 'not gmail') {
    return res.json(reply.failed("Signup with Gmail"));
  }
  else if (value === 'number') {
    request.mobile = parseInt(request.email)
    request.email = "";
  }
  else if (value !== 'email') {
    return res.json(reply.failed("Invalid email or mobile number"));
  }


  //password strenght check
  // if (!checkPasswordStrength(request.password)) {
  //   return res.json(reply.failed("Weak password."));
  // }


  try {

    //pending user
    const existingPendingUser = await RegPending.findOne({
      $or: [{ email: request.email }, { mobile: request.mobile }]
    });

    if (existingPendingUser) {
      return res.json(reply.failed("Verification Pending"));
    }

    //already registered user
    const existingUser = await Users.findOne({
      $or: [{ email: request.email }, { mobile: request.mobile }]
    });

    if (existingUser) {
      return res.json(reply.failed("Email or mobile already exists"));
    }




    const saltRounds = 10;
    const salt = bcrypt.genSaltSync(saltRounds);
    let password = bcrypt.hashSync(request.password, salt);
    request.password = password;


    let referal_id = await generateReferalId();
    request.referal_id = referal_id;

    console.log("request", request);


    const newUser = await RegPending.create(request);
    console.log('User registered successfully:', newUser.toJSON());

   // Otp generator
   const otp = await helper.generateOTP(request.email)

   //sending mail
   if(request.email){

        Mail.send(request.email, 'Registration', otp);
   }


    return res.json(reply.success("Verification Mail Sent successfully"));
  } catch (err) {
    return res.json(reply.error("An error occurred during registration"));
  }
}

const verifyOtp = async (req, res) => {
  try {
    const { otp, email } = req.body;
 
    if(!otp)
    return res.json(reply.failed("Otp is required"));

    const latestOtpRecord = await OtpSchema.findOne({
      where: { email },
      order: [['createdAt', 'DESC']]
    });

    if (!latestOtpRecord || parseInt(otp) !== parseInt(latestOtpRecord.otp)) {
      return res.json(reply.failed('The OTP is not valid or expired'));
    }

    // Check if OTP is expired 
    const otpCreatedAt = latestOtpRecord.createdAt;
    const currentTime = new Date();
    const otpExpirationTime = new Date(otpCreatedAt.getTime() + 5 * 60 * 1000);

    await OtpSchema.destroy({ where: { email } });

    if (currentTime > otpExpirationTime) {
      return res.json(reply.failed('The OTP is expired'));
    }


    //Transfer records
    const recordsToMove = await RegPending.findOne({ where: { email } });
    await Users.create(recordsToMove.dataValues);
    await recordsToMove.destroy();


    return res.json(reply.success("Registration successful"));
  } catch (error) {
    return res.json(reply.failed("An error occurred while processing your request"));
  }
}


const login = async (req, res) => {
  const { email, password, details } = req.body;


  if (!email || !password) {
    return res.json(reply.failed("Credentials required"));
  }


  let user = await Users.findOne({ where: { email: email } });
  if (!user) return res.json(reply.failed('Invalid login credentials'));

  let pass = await bcrypt.compare(password, user.password);
  if (!pass) return res.json(reply.failed('Invalid login credentials'));

  const JTI = Date.now();
  let data = { user_id: user.id, email: user.email, jti: JTI };

  const TOKEN = JWT.sign(data, process.env.JWT_KEY, { expiresIn: "24h" });
  let user_data = { 'user': user, 'token': TOKEN };


  await ClientActivityLog.create(details);

  // let remoteAddress = req.ip;
  // console.log("ipv6 address", remoteAddress)

  // const address = new Address6('2405:201:5023:484b:5cf1:cec1:3aa9:d485');
  // const teredo = address.inspectTeredo();
  // console.log("ipv4 address",teredo.client4);

  const clientIp = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
  console.log("clientIp", clientIp)
  console.log("req.ip",req.ip)

  fetch("https://api.ipify.org?format=json")
    .then(response => response.json())
    .then(data => {
      console.log("data", data.ip)
      fetchAndSaveData(email,data.ip);
    });

  return res.json(reply.success('User login Successfully', user_data));
}

export default {
  register,
  verifyOtp,
  login
}
