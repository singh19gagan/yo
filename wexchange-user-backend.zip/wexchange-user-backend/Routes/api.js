import express from 'express';
import AuthController from "../Controllers/AuthController.js";
import PostController from "../Controllers/PostController.js";
import helpers from '../Utils/helpers.js';
const router = express.Router();


router.post('/register', AuthController.register);
router.post('/verifyotp', AuthController.verifyOtp);
router.post('/login', AuthController.login);

//post req
router.post('/registerSMTPUser', PostController.registerSMTPUser);
router.post('/setTemplate', PostController.setTemplate);
router.post('/setUserDetails', PostController.setUserDetails);

router.get('/fetchcountries', helpers.fetchcountries);


export const ApiRoute = router;