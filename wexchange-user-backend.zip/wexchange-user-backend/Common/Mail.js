import nodeMailer from 'nodemailer'
import SMTPDetails from "../Models/SMTPDetails.js";
import MailTemplate from "../Models/MailTemplate.js";
import dotenv from "dotenv";
dotenv.config();

         export default {
    send: async (to,subject,otp) => {
        const smtp = await SMTPDetails.findOne({ where: { status: true } });
        if (!smtp) {
          throw new Error('No active SMTP details found');
        }

        const template = await MailTemplate.findOne({ where: { title:subject } });
        if (!template) {
          throw new Error('No email template found for the given action');
        }
      
        let transporter = nodeMailer.createTransport({
            host: smtp.mail_host,
            port: smtp.mail_port,
            secure: false,
            auth: {
                user: smtp.email,
                pass: smtp.password
            }
        });

        let mail_from = smtp.mail_from_address || "";
        let name_from = smtp.mail_from_name || "";
        let mailOptions = {
            from: `"${name_from}" <${mail_from}>`, // sender address
            to: to, // list of receivers
            subject, // Subject line
            // text, // plain text body
            // html // html body
        };


            mailOptions.subject = subject
            mailOptions.text = subject
            mailOptions.html = template.template
            .replaceAll('$otp', otp)
            .replaceAll('$to', to)
            .replaceAll('$mailfromname', name_from);
        

        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                console.log(error);
                return
            }
            console.log('Message %s sent: %s', info.messageId, info.response);
        });
    }
}
