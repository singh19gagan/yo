import otpGenerator from 'otp-generator';
import Users from '../Models/Users.js';
import reply from './reply.js';
import OtpSchema from '../Models/OtpSchema.js';
import { countries } from 'country-data-list';
const generateOTP = async (email) => {
  
  try {
    let otp = otpGenerator.generate(4, {
      upperCaseAlphabets: false,
      lowerCaseAlphabets: false,
      specialChars: false,
    });

    let result = await OtpSchema.findOne({ where: { otp: otp } });
    while (result) {
      otp = otpGenerator.generate(4, {
        upperCaseAlphabets: false,
      });
       result = await OtpSchema.findOne({ where: { otp: otp } });
    }
    const otpPayload = { email, otp };
    await OtpSchema.create(otpPayload);

    return otp;
    
  } catch (err) {
    console.log({ err });
    throw err;
  }
};

const fetchcountries = async (req,res) => {
  try {
    const country =[...countries.all];
    return res.json(reply.success(country));
  } catch (error) {
    console.error('Error fetching countries:', error);
  }
}

export default {
    generateOTP,
    fetchcountries
  }

